<?php
/* @var $this MechController */
/* @var $model Mech */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'s_no'); ?>
		<?php echo $form->textField($model,'s_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'dep_id'); ?>
		<?php echo $form->textField($model,'dep_id',array('size'=>60,'maxlength'=>100)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'faculty_no'); ?>
		<?php echo $form->textField($model,'faculty_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'labs_no'); ?>
		<?php echo $form->textField($model,'labs_no'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->