<?php
/* @var $this MechController */
/* @var $model Mech */

$this->breadcrumbs=array(
	'Meches'=>array('index'),
	$model->s_no=>array('view','id'=>$model->s_no),
	'Update',
);

$this->menu=array(
	array('label'=>'List Mech', 'url'=>array('index')),
	array('label'=>'Create Mech', 'url'=>array('create')),
	array('label'=>'View Mech', 'url'=>array('view', 'id'=>$model->s_no)),
	array('label'=>'Manage Mech', 'url'=>array('admin')),
);
?>

<h1>Update Mech <?php echo $model->s_no; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>