<?php
/* @var $this MechController */
/* @var $model Mech */

$this->breadcrumbs=array(
	'Meches'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Mech', 'url'=>array('index')),
	array('label'=>'Manage Mech', 'url'=>array('admin')),
);
?>

<h1>Create Mech</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>