<?php
/* @var $this MechController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Meches',
);

$this->menu=array(
	array('label'=>'Create Mech', 'url'=>array('create')),
	array('label'=>'Manage Mech', 'url'=>array('admin')),
);
?>

<h1>Meches</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
