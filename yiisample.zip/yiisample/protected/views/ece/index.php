<?php
/* @var $this EceController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Eces',
);

$this->menu=array(
	array('label'=>'Create Ece', 'url'=>array('create')),
	array('label'=>'Manage Ece', 'url'=>array('admin')),
);
?>

<h1>Eces</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
