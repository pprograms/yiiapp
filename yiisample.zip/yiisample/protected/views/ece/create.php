<?php
/* @var $this EceController */
/* @var $model Ece */

$this->breadcrumbs=array(
	'Eces'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Ece', 'url'=>array('index')),
	array('label'=>'Manage Ece', 'url'=>array('admin')),
);
?>

<h1>Create Ece</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>