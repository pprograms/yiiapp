<?php
/* @var $this EceController */
/* @var $data Ece */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('s_no')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->s_no), array('view', 'id'=>$data->s_no)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('dep_id')); ?>:</b>
	<?php echo CHtml::encode($data->dep_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('faculty_no')); ?>:</b>
	<?php echo CHtml::encode($data->faculty_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('labs_no')); ?>:</b>
	<?php echo CHtml::encode($data->labs_no); ?>
	<br />


</div>