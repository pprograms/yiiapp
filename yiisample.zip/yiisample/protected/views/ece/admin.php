<?php
/* @var $this EceController */
/* @var $model Ece */

$this->breadcrumbs=array(
	'Eces'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List Ece', 'url'=>array('index')),
	array('label'=>'Create Ece', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#ece-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>About Ece ddpartment</h1>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'ece-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		's_no',
		'dep_id',
		'faculty_no',
		'labs_no',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
