<?php
/* @var $this EceController */
/* @var $model Ece */

$this->breadcrumbs=array(
	'Eces'=>array('index'),
	$model->s_no=>array('view','id'=>$model->s_no),
	'Update',
);

$this->menu=array(
	array('label'=>'List Ece', 'url'=>array('index')),
	array('label'=>'Create Ece', 'url'=>array('create')),
	array('label'=>'View Ece', 'url'=>array('view', 'id'=>$model->s_no)),
	array('label'=>'Manage Ece', 'url'=>array('admin')),
);
?>

<h1>Update Ece <?php echo $model->s_no; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>