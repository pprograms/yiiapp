<?php
/* @var $this EeeController */
/* @var $model Eee */

$this->breadcrumbs=array(
	'Eees'=>array('index'),
	$model->s_no=>array('view','id'=>$model->s_no),
	'Update',
);

$this->menu=array(
	array('label'=>'List Eee', 'url'=>array('index')),
	array('label'=>'Create Eee', 'url'=>array('create')),
	array('label'=>'View Eee', 'url'=>array('view', 'id'=>$model->s_no)),
	array('label'=>'Manage Eee', 'url'=>array('admin')),
);
?>

<h1>Update Eee <?php echo $model->s_no; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>