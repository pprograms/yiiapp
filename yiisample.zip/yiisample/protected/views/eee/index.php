<?php
/* @var $this EeeController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Eees',
);

$this->menu=array(
	array('label'=>'Create Eee', 'url'=>array('create')),
	array('label'=>'Manage Eee', 'url'=>array('admin')),
);
?>

<h1>Eees</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
