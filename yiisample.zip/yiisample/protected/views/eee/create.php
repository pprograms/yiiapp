<?php
/* @var $this EeeController */
/* @var $model Eee */

$this->breadcrumbs=array(
	'Eees'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Eee', 'url'=>array('index')),
	array('label'=>'Manage Eee', 'url'=>array('admin')),
);
?>

<h1>Create Eee</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>