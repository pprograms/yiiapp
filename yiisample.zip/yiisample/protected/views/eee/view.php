<?php
/* @var $this EeeController */
/* @var $model Eee */

$this->breadcrumbs=array(
	'Eees'=>array('index'),
	$model->s_no,
);

$this->menu=array(
	array('label'=>'List Eee', 'url'=>array('index')),
	array('label'=>'Create Eee', 'url'=>array('create')),
	array('label'=>'Update Eee', 'url'=>array('update', 'id'=>$model->s_no)),
	array('label'=>'Delete Eee', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->s_no),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Eee', 'url'=>array('admin')),
);
?>

<h1>View Eee #<?php echo $model->s_no; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		's_no',
		'dep_id',
		'faculty_no',
		'labs_no',
	),
)); ?>
