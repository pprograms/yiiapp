<?php
/* @var $this CseController */
/* @var $model Cse */

$this->breadcrumbs=array(
	'Cses'=>array('index'),
	$model->s_no=>array('view','id'=>$model->s_no),
	'Update',
);

$this->menu=array(
	array('label'=>'List Cse', 'url'=>array('index')),
	array('label'=>'Create Cse', 'url'=>array('create')),
	array('label'=>'View Cse', 'url'=>array('view', 'id'=>$model->s_no)),
	array('label'=>'Manage Cse', 'url'=>array('admin')),
);
?>

<h1>Update Cse <?php echo $model->s_no; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>