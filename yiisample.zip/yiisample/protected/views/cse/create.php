<?php
/* @var $this CseController */
/* @var $model Cse */

$this->breadcrumbs=array(
	'Cses'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Cse', 'url'=>array('index')),
	array('label'=>'Manage Cse', 'url'=>array('admin')),
);
?>

<h1>Create Cse</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>