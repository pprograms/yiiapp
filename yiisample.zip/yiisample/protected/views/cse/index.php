<?php
/* @var $this CseController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Cses',
);

$this->menu=array(
	array('label'=>'Create Cse', 'url'=>array('create')),
	array('label'=>'Manage Cse', 'url'=>array('admin')),
);
?>

<h1>Cses</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
