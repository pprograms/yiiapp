<?php
/* @var $this CseController */
/* @var $model Cse */

$this->breadcrumbs=array(
	'Cses'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List Cse', 'url'=>array('index')),
	array('label'=>'Create Cse', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#cse-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>About Cse Department</h1>
<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'cse-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		's_no',
		'dep_id',
		'faculty_no',
		'labs_no',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
